
/**
 *
 * @author brita
 */

package ENTIDAD;

public class USUA {
    private String ID;
    private String NOMBRE;
    private String ROLES;

    public USUA(String id, String nombre, String rol){
        this.ID=id;
        this.NOMBRE=nombre;
        this.ROLES=rol;
    }

    public String getId(){ return ID; }
    public String getNombre(){ return NOMBRE; }
    public String getRol(){ return ROLES; }

    public String getrol() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getnombre() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getd() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}