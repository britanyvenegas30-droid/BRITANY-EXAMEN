/**
 *
 * @author brita
 */

package ENTIDAD;

import java.time.LocalDateTime;

public class ACCESS {

    private String IDusuario;
    private LocalDateTime ENTRADA;
    private LocalDateTime SALIDA;

    public ACCESS(String idUsuario, LocalDateTime entrada){
        this.IDusuario=idUsuario;
        this.ENTRADA=entrada;
    }

    public void registrarSalida(LocalDateTime salida){
        this.SALIDA=salida;
    }

    public String getIdUsuario(){ return IDusuario; }
    public LocalDateTime getEntrada(){ return ENTRADA; }
    public LocalDateTime getSalida(){ return SALIDA; }
}