package PRESENTA;

public class PRINCIPAL {

    public static void main(String[] args){
        MENU menu = new MENU();
        menu.iniciar();
    }

}