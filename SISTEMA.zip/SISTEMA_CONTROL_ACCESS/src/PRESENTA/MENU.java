package PRESENTA;

import java.util.Scanner;

public class MENU {

    Scanner SCANNER = new Scanner(System.in);

    public void iniciar(){

        int op;

        do{

            System.out.println("      SISTEMA CONTROL      ");

            System.out.println("1- REGISTRAR USUARIO");
            System.out.println("2- CONSULTAR USUARIOS");
            System.out.println("3- ELIMINAR USUARIO");
            System.out.println("0- SALIR");

            System.out.println("SELECCIONE LA OPCION:");

            op = SCANNER.nextInt();

            switch(op){

                case 1:
                    registrarUsuario();
                break;
                case 2:
                    consultarUsuarios();
                break;
                case 3:
                    elim_Usuario();
                break;
                case 0:
                    System.out.println("SALIENDO DEL SISTEMA");
                break;
                default:

                    System.out.println("OPCION INVALIDA");

            }

        }while(op!=0);

    }

    private void registrarUsuario(){

        SCANNER.nextLine();

        System.out.println("INGRESE EL ID:");

        String id = SCANNER.nextLine();

        System.out.println("INGRESE EL NOMBRE:");

        String nombre = SCANNER.nextLine();

        System.out.println("INGRESE EL ROL:");

        String rol = SCANNER.nextLine();

        System.out.println("USUARIO REGISTRADO CORRECTAMENTE");

        System.out.println(id+" - "+nombre+" - "+rol);

    }

    private void consultarUsuarios(){

        System.out.println("AQUI SE MOSTRARAN LOS USUARIOS");

    }

    private void elim_Usuario(){

        SCANNER.nextLine();
        System.out.println("INGRESE EL ID A ELIMINAR:");
        String id = SCANNER.nextLine();
        System.out.println("USUARIO "+id+" ELIMINADO");

    }

}