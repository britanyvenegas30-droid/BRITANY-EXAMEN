package ACCESODATO;


import ENTIDAD.USUA;
import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class AccesoDatosTXT {
    private final String RUTA = "usuarios.txt";

    public void escribirUsuario(USUA usuario) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RUTA, true))) {
            writer.write(usuario.getrol() + usuario.getd() + "," + usuario.getnombre() + ",");
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error al guardar datos: " + e.getMessage());
        }
    }

    public List<USUA> leerTodos() {
        List<USUA> lista = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(RUTA))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] d = linea.split(",");
                if (d.length == 3) {
                 
                }
            }
        } catch (IOException e) {
            // El archivo se creará cuando se registre el primer usuario
        }
        return lista;
    }
}