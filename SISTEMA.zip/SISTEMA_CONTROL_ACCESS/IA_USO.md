# IA_USO

## Prompts que utiliec
1 Ayuda para mejorar estructura de menú Java
2 Corrección de validaciones
3 Mejores prácticas arquitectura por capas

## Qué hizp la IA
Correcciones de sintaxis
Sugerencias de organización
Ejemplos de validaciones

## Ajuste de  manera manuakmente
Adaptación del código
Implementación de archivos TXT
Organización de paquetes


