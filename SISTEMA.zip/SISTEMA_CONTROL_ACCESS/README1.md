# Sistema de Control de Acceso 
## Descrip
Aplicación desarrollada en Java que permite gestionar el acceso de usuarios a un laboratorio técnico mediante arquitectura por capas.

## Funcion
- Registro de usuarios
- Consulta de usuarios
- Reportes de tiempo dentro del laboratorio

## Estructuraa
El sistema utiliza arquitectura por capas:

Entidades → Clases del modelo de datos  
AccesoDatos → Manejo de archivos TXT  
LogicaNegocio → Validaciones y reglas  
Presentacion → Menú del sistema  

## Que utilice
- Java
- Archivos TXT
- GitHub

## Ejeucute
1 Descargar el proyecto
2 Ejecutar la clase principal Sistema_Control_Access
3 Usar el menú del sistema


